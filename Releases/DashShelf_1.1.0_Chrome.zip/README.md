# DashShelf 
![alt text](https://github.com/JadBlackstone/DashShelf/blob/main/icon_128.png?raw=true)  
DashShelf creates a clean dashbaord of all your bookmarks and bookmarkfolders. You only need to organize your bookmarks in Google Chrome and the Plugin use them from there without manual work. The dashboard will open as the default for new tab and if you click on one of the bookmarks, it will open in another tab, keeping your dashboard usable.

## Installation
* Open Chrome Settings
* Go to Exentsions
* Toggle Developer-Mode
* Load unpacked Extension

## Contribution
I am open to all kinds of Contribution.
If somebody would like to publish this extensions in the Chrome Shop, please send me a message.
